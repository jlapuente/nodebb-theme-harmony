{{{ each sessions }}}
<li class="list-group-item text-break" data-uuid="{./uuid}">
	<div class="float-end">
		{{{ if isSelfOrAdminOrGlobalModerator }}}
		{{{ if !./current }}}
		<button class="btn btn-sm btn-outline-secondary" type="button" data-action="revokeSession">{{tx("user:revoke-session")}}</button>
		{{{ end }}}
		{{{ end }}}
		{{userAgentIcons(@value)}}
		<i class="fa fa-circle text-{{{ if ./current }}}success{{{ else }}}muted{{{ end }}}"></i>
	</div>
	{{tx("user:browser-version-on-platform", ./browser, ./version, ./platform)}}<br />
	<small class="timeago text-muted" title="{./datetimeISO}"></small>
	<ul>
		<li><strong>{{tx("global:ip-address")}}</strong>: {./ip}</li>
	</ul>
</li>
{{{ end }}}
