<!-- IMPORT partials/topic/post-meta-tags.tpl -->

{{{ if (!./index && widgets.mainpost-header.length) }}}
<div data-widget-area="mainpost-header">
	{{{ each widgets.mainpost-header }}}
	{{widgets.mainpost-header.html}}
	{{{ end }}}
</div>
{{{ end }}}
{{{ if (./parent && !hideParent) }}}
<!-- IMPORT partials/topic/post-parent.tpl -->
{{{ end }}}
<div class="d-flex align-items-start gap-3 post-container-parent">
	<div class="bg-body d-none d-sm-block rounded-circle" style="box-shadow: 0 0 0 3px var(--bs-body-bg);">
		<a class="d-inline-block position-relative text-decoration-none" href="{{{ if ./user.userslug }}}{config.relative_path}/user/{./user.userslug}{{{ else }}}#{{{ end }}}" aria-label="{{tx("aria:profile-page-for", txEscape(txDisplayname(./user)))}}">
			{{buildAvatar(posts.user, "48px", true, "", "user/picture")}}
			<!-- IMPORT partials/topic/user-status.tpl -->
		</a>
	</div>
	<div class="post-container d-flex gap-2 flex-grow-1 flex-column w-100" style="min-width:0;">
		<div class="d-flex align-items-start justify-content-between gap-1 flex-nowrap w-100 post-header">
			<div class="d-flex gap-1 flex-wrap align-items-center text-truncate">
				<div class="d-flex flex-nowrap gap-1 align-items-center text-truncate">
					<div class="d-sm-none">
						<a class="d-inline-block position-relative text-decoration-none" href="{{{ if ./user.userslug }}}{config.relative_path}/user/{./user.userslug}{{{ else }}}#{{{ end }}}">
							{{buildAvatar(posts.user, "20px", true, "", "user/picture")}}
							<!-- IMPORT partials/topic/user-status.tpl -->
						</a>
					</div>

					<a class="fw-bold text-nowrap text-truncate" href="{{{ if ./user.userslug }}}{config.relative_path}/user/{./user.userslug}{{{ else }}}#{{{ end }}}" data-username="{posts.user.username}" data-uid="{posts.user.uid}">{{renderShortcodeEmoji(txDisplayname(posts.user), posts.user.fullnameEmoji)}}</a>
				</div>

				{{{ each posts.user.selectedGroups }}}
				{{{ if posts.user.selectedGroups.slug }}}
				<!-- IMPORT partials/groups/badge.tpl -->
				{{{ end }}}
				{{{ end }}}

				{{{ if posts.user.banned }}}
				<span class="badge bg-danger rounded-1">{{tx("user:banned")}}</span>
				{{{ end }}}

				<div class="d-flex gap-1 align-items-center">
					<span class="text-muted">{{generateWrote(@value, config.timeagoCutoff)}}</span>

					<i component="post/edit-indicator" class="fa fa-edit text-muted{{{ if privileges.posts:history }}} pointer{{{ end }}} edit-icon {{{ if !posts.editor.username }}}hidden{{{ end }}}" title="{{tx("global:edited-timestamp", isoTimeToLocaleString(./editedISO, config.userLang))}}"></i>
					<span data-editor="{posts.editor.userslug}" component="post/editor" class="visually-hidden">{{tx("global:last-edited-by", txEscape(posts.editor.username))}} <span class="timeago" title="{{isoTimeToLocaleString(posts.editedISO, config.userLang)}}"></span></span>
				</div>

				{{{ if posts.user.custom_profile_info.length }}}
				<div class="d-flex gap-1 align-items-center">
					{{{ each posts.user.custom_profile_info }}}
					{{posts.user.custom_profile_info.content}}
					{{{ end }}}
				</div>
				{{{ end }}}
			</div>
			<div class="d-flex align-items-center gap-1 justify-content-end">
				<span class="bookmarked opacity-0 text-primary"><i class="fa fa-bookmark-o"></i></span>
				<a href="{config.relative_path}/post/{encodeURIComponent(./pid)}" class="post-index text-muted d-none d-md-inline">#{increment(./index, "1")}</a>
			</div>
		</div>

		<div class="content text-break" component="post/content" itemprop="text">
			{{{ if posts.contentWarning }}}
			<details class="content-warning">
			<summary>{posts.contentWarning}</summary>
			{{{ if posts.txContent }}}{{tx(posts.content)}}{{{ else }}}{{posts.content}}{{{ end }}}
			</details>
			{{{ else }}}
			{{{ if posts.txContent }}}{{tx(posts.content)}}{{{ else }}}{{posts.content}}{{{ end }}}
			{{{ end }}}
		</div>

		<div component="post/footer" class="post-footer border-bottom pb-2">
			{{{ if posts.user.signature }}}
			<div component="post/signature" data-uid="{posts.user.uid}" class="text-xs text-muted mt-2">{{posts.user.signature}}</div>
			{{{ end }}}

			<div class="d-flex flex-wrap-reverse gap-2 {{{ if (hideReplies || !posts.replies.count) }}}justify-content-end{{{ else }}}justify-content-between{{{ end }}}">
				{{{ if !hideReplies }}}
				<a component="post/reply-count" data-target-component="post/replies/container" href="#" class="d-flex gap-2 align-items-center btn btn-ghost ff-secondary border rounded-1 p-1 text-muted text-decoration-none text-xs {{{ if (!./replies || shouldHideReplyContainer(@value)) }}}hidden{{{ end }}}">
					<span component="post/reply-count/avatars" class="d-flex gap-1 {{{ if posts.replies.hasMore }}}hasMore{{{ end }}}">
						{{{each posts.replies.users}}}
						<span>{{buildAvatar(posts.replies.users, "20px", true, "avatar-tooltip")}}</span>
						{{{end}}}
						{{{ if posts.replies.hasMore}}}
						<span style="height: 20px; line-height: 20px;"><i class="fa fa-ellipsis"></i></span>
						{{{ end }}}
					</span>

					<span class="ms-2 replies-count fw-semibold text-nowrap" component="post/reply-count/text" data-replies="{posts.replies.count}">{{tx(posts.replies.text)}}</span>
					<span class="ms-2 replies-last hidden-xs fw-semibold">{{tx("topic:last-reply-time")}} <span class="timeago" title="{posts.replies.timestampISO}"></span></span>

					<i class="fa fa-fw fa-chevron-down" component="post/replies/open"></i>
				</a>
				{{{ end }}}
				<div component="post/actions" class="d-flex flex-wrap flex-grow-1 align-items-start align-items-lg-center justify-content-end gap-1 post-tools">
					<!-- IMPORT partials/topic/reactions.tpl -->
					<div class="d-flex gap-1">
						<a component="post/reply" href="#" class="btn btn-ghost btn-sm {{{ if !privileges.topics:reply }}}hidden{{{ end }}}" title="{{tx("topic:reply")}}"><i class="fa fa-fw fa-reply text-primary"></i></a>
						<a component="post/quote" href="#" class="btn btn-ghost btn-sm {{{ if !privileges.topics:reply }}}hidden{{{ end }}}" title="{{tx("topic:quote")}}"><i class="fa fa-fw fa-quote-right text-primary"></i></a>

						{{{ if ./announces }}}
						<a component="post/announce-count" href="#" class="btn btn-ghost btn-sm d-flex gap-2 align-items-center" title="{{tx("topic:announcers")}}"><i class="fa fa-share-alt text-primary"></i> {./announces}</a>
						{{{ end }}}

						{{{ if !reputation:disabled }}}
						<div class="d-flex gap-1 votes align-items-center">
							<a component="post/upvote" href="#" class="btn btn-ghost btn-sm{{{ if posts.upvoted }}} upvoted{{{ end }}}" title="{{tx("topic:upvote-post")}}">
								<i class="fa fa-fw fa-chevron-up text-primary"></i>
							</a>

							<meta itemprop="upvoteCount" content="{posts.upvotes}">
							<meta itemprop="downvoteCount" content="{posts.downvotes}">
							<a href="#" class="px-2 btn btn-ghost btn-sm" component="post/vote-count" data-votes="{posts.votes}" title="{{tx("global:voters")}}">{posts.votes}</a>

							{{{ if !downvote:disabled }}}
							<a component="post/downvote" href="#" class="btn btn-ghost btn-sm{{{ if posts.downvoted }}} downvoted{{{ end }}}" title="{{tx("topic:downvote-post")}}">
								<i class="fa fa-fw fa-chevron-down text-primary"></i>
							</a>
							{{{ end }}}
						</div>
						{{{ end }}}

						<!-- IMPORT partials/topic/post-menu.tpl -->
					 </div>
				</div>
			</div>

			<div component="post/replies/container" class="my-2 col-11 border rounded-1 p-3 hidden-empty"></div>
		</div>
	</div>
</div>

{{{ if (!./index && widgets.mainpost-footer.length) }}}
<div data-widget-area="mainpost-footer">
	{{{ each widgets.mainpost-footer }}}
	{{widgets.mainpost-footer.html}}
	{{{ end }}}
</div>
{{{ end }}}