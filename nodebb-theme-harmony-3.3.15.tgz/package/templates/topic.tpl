<!-- IMPORT partials/breadcrumbs-json-ld.tpl -->
{{{ if config.theme.enableBreadcrumbs }}}
<!-- IMPORT partials/breadcrumbs.tpl -->
{{{ end }}}
{{{ if widgets.header.length }}}
<div data-widget-area="header">
{{{each widgets.header}}}
{{widgets.header.html}}
{{{end}}}
</div>
{{{ end }}}

<div class="flex-fill" itemid="{url}" itemscope itemtype="https://schema.org/DiscussionForumPosting">
	<!-- IMPORT partials/topic/meta-tags.tpl -->

	<div class="d-flex flex-column gap-3">
		<div class="d-flex gap-2 flex-wrap flex-column flex-md-row {{{ if config.theme.centerHeaderElements }}}justify-content-center{{{ else }}}justify-content-between{{{ end }}}">
			<div class="d-flex flex-column gap-3 flex-md-shrink-50">
				<h1 component="post/header" class="tracking-tight fw-semibold fs-3 mb-0 text-break {{{ if config.theme.centerHeaderElements }}}text-center{{{ end }}}">
					<span class="topic-title" component="topic/title">{{renderShortcodeEmoji(title, titleEmoji)}}</span>
				</h1>

				<div class="topic-info d-flex gap-2 align-items-center flex-wrap {{{ if config.theme.centerHeaderElements }}}justify-content-center{{{ end }}}">
					<span component="topic/labels" class="d-flex gap-2 {{{ if (!scheduled && (!pinned && (!locked && (!icons.length && (!oldCid || (oldCid == "-1")))))) }}}hidden{{{ end }}}">
						<span component="topic/scheduled" class="badge border border-gray-300 text-body {{{ if !scheduled }}}hidden{{{ end }}}">
							<i class="fa fa-clock-o"></i> {{tx("topic:scheduled")}}
						</span>
						<span component="topic/pinned" class=" badge border border-gray-300 text-body {{{ if (scheduled || !pinned) }}}hidden{{{ end }}}">
							<i class="fa fa-thumb-tack"></i> {{{ if !pinExpiry }}}{{tx("topic:pinned")}}{{{ else }}}{{tx("topic:pinned-with-expiry", isoTimeToLocaleString(./pinExpiryISO, config.userLang))}}{{{ end }}}
						</span>
						<span component="topic/locked" class="badge border border-gray-300 text-body {{{ if !locked }}}hidden{{{ end }}}">
							<i class="fa fa-lock"></i> {{tx("topic:locked")}}
						</span>
						<a component="topic/moved" href="{config.relative_path}/category/{oldCid}" class="badge border border-gray-300 text-body text-decoration-none {{{ if (!oldCid || (oldCid == "-1")) }}}hidden{{{ end }}}">
							<i class="fa fa-arrow-circle-right"></i> {{{ if privileges.isAdminOrMod }}}{{tx("topic:moved-from", oldCategory.name)}}{{{ else }}}{{tx("topic:moved")}}{{{ end }}}
						</a>
						{{{ each ./icons }}}<!-- IMPORT partials/topic/icon.tpl -->{{{ end }}}
					</span>
					{{buildCategoryLabel(category, "a", "border")}}
					<div data-tid="{./tid}" component="topic/tags" class="lh-1 tags tag-list d-flex flex-wrap hidden-xs hidden-empty gap-2"><!-- IMPORT partials/topic/tags.tpl --></div>
					<div class="d-flex gap-2" component="topic/stats"><!-- IMPORT partials/topic/stats.tpl --></div>

					{{{ if (!feeds:disableRSS && rssFeedUrl) }}}
					<a class="badge border border-gray-300 text-body text-decoration-none d-flex align-items-center align-self-stretch" target="_blank" href="{rssFeedUrl}" title="{{tx("global:rss-feed")}}"><i class="fa fa-rss fa-sm text-muted lh-1"></i></a>
					{{{ end }}}
				</div>
			</div>
			<div class="flex-shrink-1 d-flex flex-wrap gap-2 align-items-start mt-2 hidden-empty {{{ if greaterthan(thumbs.length, "4") }}}thumbs-collapsed{{{ end }}}" component="topic/thumb/list"><!-- IMPORT partials/topic/thumbs.tpl --></div>
		</div>

		<div class="row mb-4 mb-lg-0">
			<div class="topic {{{ if widgets.sidebar.length }}}col-lg-9 col-sm-12{{{ else }}}col-lg-12{{{ end }}}">
				<!-- IMPORT partials/post_bar.tpl -->
				{{{ if merger }}}
				<!-- IMPORT partials/topic/merged-message.tpl -->
				{{{ end }}}
				{{{ if forker }}}
				<!-- IMPORT partials/topic/forked-message.tpl -->
				{{{ end }}}
				{{{ if !scheduled }}}
				<!-- IMPORT partials/topic/deleted-message.tpl -->
				{{{ end }}}

				<div class="d-flex gap-0 gap-lg-5">
					<div class="posts-container" style="min-width: 0;">
						<ul component="topic" class="posts timeline list-unstyled p-0 py-3" style="min-width: 0;" data-tid="{tid}" data-cid="{cid}">
						{{{ each posts }}}
							<li component="post" class="{{{ if (./index != 0) }}}pt-4{{{ end }}} {{{ if posts.deleted }}}deleted{{{ end }}} {{{ if posts.selfPost }}}self-post{{{ end }}} {{{ if posts.topicOwnerPost }}}topic-owner-post{{{ end }}}" <!-- IMPORT partials/data/topic.tpl -->>
								<a component="post/anchor" data-index="{./index}" id="{increment(./index, "1")}"></a>

								<!-- IMPORT partials/topic/post.tpl -->
							</li>
							{{{ if (config.topicPostSort != "most_votes") }}}
							{{{ each ./events}}}<!-- IMPORT partials/topic/event.tpl -->{{{ end }}}
							{{{ end }}}
						{{{ end }}}
						</ul>
						{{{ if browsingUsers }}}
						<div class="visible-xs">
							<!-- IMPORT partials/topic/browsing-users.tpl -->
							<hr/>
						</div>
						{{{ end }}}
						{{{ if config.theme.enableQuickReply }}}
						<!-- IMPORT partials/topic/quickreply.tpl -->
						{{{ end }}}
						{{{ if !config.loggedIn }}}
						<!-- IMPORT partials/topic/guest-cta.tpl -->
						{{{ end }}}
					</div>
					<div class="d-flex d-none d-lg-block flex-grow-1 mt-2">
						<div class="sticky-top" style="{{{ if config.theme.topicSidebarTools }}}top:2rem;{{{ else }}}top:6rem; {{{ end }}} z-index:1;">
							<div class="d-flex flex-column gap-3 align-items-end">
								{{{ if config.theme.topicSidebarTools }}}
								<div class="topic-sidebar-tools d-flex flex-column gap-2" style="width: 170px;">
									<!-- IMPORT partials/topic/reply-button.tpl -->
									<!-- IMPORT partials/topic/mark-unread.tpl -->
									<!-- IMPORT partials/topic/watch.tpl -->
									<!-- IMPORT partials/topic/sort.tpl -->
									<!-- IMPORT partials/topic/crosspost.tpl -->
									<!-- IMPORT partials/topic/tools.tpl -->
								</div>
								{{{ end }}}
								{{{ if config.theme.topicSidebarTools }}}<hr class="my-0" style="min-width: 170px;"/>{{{ end }}}
								<!-- IMPORT partials/topic/navigator.tpl -->
								{{{ if config.theme.topicSidebarTools }}}<hr class="my-0" style="min-width: 170px;" />{{{ end }}}
								{{{ if browsingUsers }}}
								<div class="d-flex flex-column ps-2 hidden-xs" style="min-width: 170px;">
								<!-- IMPORT partials/topic/browsing-users.tpl -->
								</div>
								{{{ end }}}
							</div>
						</div>
					</div>
				</div>

				{{{ if config.usePagination }}}
				<!-- IMPORT partials/paginator.tpl -->
				{{{ end }}}
			</div>
			<div data-widget-area="sidebar" class="col-lg-3 col-sm-12 {{{ if !widgets.sidebar.length }}}hidden{{{ end }}}">
			{{{each widgets.sidebar}}}
			{{widgets.sidebar.html}}
			{{{end}}}
			</div>
		</div>
	</div>
</div>

<div data-widget-area="footer">
{{{each widgets.footer}}}
{{widgets.footer.html}}
{{{end}}}
</div>

{{{ if !config.usePagination }}}
<noscript>
<!-- IMPORT partials/paginator.tpl -->
</noscript>
{{{ end }}}
