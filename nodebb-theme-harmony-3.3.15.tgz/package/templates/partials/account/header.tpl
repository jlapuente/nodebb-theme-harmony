<div class="account w-100 mx-auto">
	<div class="cover position-absolute start-0 top-0 w-100" component="account/cover" style="background-image: url({cover:url}); background-position: {cover:position};">
		<div class="container">
			{{{ if (allowCoverPicture && canEdit) }}}
			<div class="controls text-center">
				<a href="#" class="upload p-2 m-2 rounded-1 text-bg-light opacity-75"><i class="fa fa-fw fa-upload"></i></a>
				<a href="#" class="resize p-2 m-2 rounded-1 text-bg-light opacity-75"><i class="fa fa-fw fa-arrows"></i></a>
				<a href="#" class="remove p-2 m-2 rounded-1 text-bg-light opacity-75"><i class="fa fa-fw fa-times"></i></a>
			</div>
			<a href="#" class="save btn btn-primary">{{tx("groups:cover-save")}} <i class="fa fa-fw fa-floppy-o"></i></a>
			<div class="indicator text-bg-primary">{{tx("groups:cover-saving")}} <i class="fa fa-fw fa-refresh fa-spin"></i></div>
			{{{ end }}}
		</div>
	</div>

	<div class="d-flex flex-column flex-md-row gap-2 w-100 pb-4 mb-4 mt-2 border-bottom">
		<div class="avatar-wrapper bg-body rounded-circle position-relative align-self-center align-self-md-start hover-parent" style="margin-top: -75px; padding: 4px;">
			{{buildAvatar(@value, "142px", true)}}
			{{{ if (allowProfilePicture && isSelfOrAdminOrGlobalModerator)}}}
			<a href="#" component="profile/change/picture" class="d-none d-md-block pointer p-2 rounded-1 text-bg-light position-absolute top-50 start-50 translate-middle hover-opacity-75">
				<span class="upload"><i class="fa fa-fw fa-upload"></i></span>
			</a>
			{{{ end }}}
		</div>

		<div class="d-flex flex-column flex-md-row mt-1 justify-content-between w-100 gap-2">
			<div class="d-flex flex-grow-1 flex-row gap-2">
				<div class="d-flex flex-column gap-1">
					<h2 class="fullname fw-semibold fs-2 tracking-tight mb-0">{{{ if fullname }}}{{renderShortcodeEmoji(fullname, fullnameEmoji)}}{{{ else }}}{username}{{{ end }}}</h2>
					<div class="d-flex flex-wrap gap-1 text-sm align-items-center">
						<span class="username fw-bold">@{username}</span>
						<div class="d-flex align-items-center gap-1 p-1 flex-wrap">
							{{{ if selectedGroup.length }}}
							{{{ each selectedGroup }}}
							{{{ if ./slug }}}
							<!-- IMPORT partials/groups/badge.tpl -->
							{{{ end }}}
							{{{ end }}}
							{{{ end }}}
						</div>
					</div>
					<div class="d-flex gap-2" component="user/badges"></div>
					{{{ if isAdminOrGlobalModeratorOrModerator }}}
					{{{ if banned }}}
					<div class="text-sm text-muted">
						{{{ if banned_until }}}
						{{tx("user:info.banned-until", isoTimeToLocaleString(./banned_until_readable, config.userLang))}}
						{{{ else }}}
						{{tx("user:info.banned-permanently")}}
						{{{ end }}}
					</div>
					{{{ end }}}
					{{{ if muted }}}
					<div class="text-sm text-muted">
						{{{ if mutedUntil }}}
						{{tx("user:info.muted-until", isoTimeToLocaleString(./muted_until_readable, config.userLang))}}
						{{{ else }}}
						{{tx("user:info.muted-permanently")}}
						{{{ end }}}
					</div>
					{{{ end }}}
					{{{ end }}}
				</div>
			</div>

			<div class="flex-shrink-0 d-flex gap-1 align-self-stretch align-self-md-start justify-content-end">
				{{{ if !isSelf }}}
				<a component="account/unfollow" href="#" class="btn btn-outline-warning flex-fill{{{ if (!isFollowing && !isFollowPending) }}} hide{{{ end }}}">
					{{{ if isFollowPending }}}{{tx("user:cancel-follow")}}{{{ else }}}{{tx("user:unfollow")}}{{{ end }}}
				</a>
				<a component="account/follow" href="#" class="btn btn-primary flex-fill{{{ if (isFollowing || isFollowPending) }}} hide{{{ end }}}">{{tx("user:follow")}}</a>
				{{{ end }}}

				{{{ if (canChat && !banned) }}}
				<div class="btn-group flex-fill">
					<a {{{ if hasPrivateChat }}}component="account/chat"{{{ else }}}component="account/new-chat"{{{ end }}} href="#" class="btn btn-light" role="button">{{tx("user:chat")}}</a>
					{{{ if hasPrivateChat}}}
					<button type="button" class="btn btn-light dropdown-toggle flex-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="fa fa-caret-down"></i>
					</button>
					<ul class="dropdown-menu dropdown-menu-end p-1 text-sm" role="menu">
						<li><a class="dropdown-item rounded-1" href="#" component="account/new-chat" role="menuitem">{{tx("user:new-chat-with", txEscape(username))}}</a></li>
					</ul>
					{{{ end }}}
				</div>
				{{{ end }}}
				{{{ if !isSelf }}}
				{{{ if (isAdmin || (canBan || canMute ))}}}
				<!-- IMPORT partials/account/admin-menu.tpl -->
				{{{ end }}}
				{{{ end }}}
			</div>
		</div>
	</div>

	<div data-widget-area="header">
		{{{each widgets.header}}}
		{{widgets.header.html}}
		{{{end}}}
	</div>

	<div class="d-flex flex-column flex-md-row">
		<!-- IMPORT partials/account/sidebar-left.tpl -->
		<div class="account-content flex-grow-1 ps-md-2 ps-lg-3 ps-xl-4" style="min-width: 0;">

