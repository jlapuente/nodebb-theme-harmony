<span component="post/tools" class="dropdown bottom-sheet {{{ if !./display_post_menu }}}hidden{{{ end }}}">
	<a class="btn btn-ghost btn-sm ff-secondary dropdown-toggle" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="{{tx("topic:post-tools")}}"><i class="fa fa-fw fa-ellipsis-v text-primary"></i></a>
	<ul class="dropdown-menu dropdown-menu-end p-1 text-sm" role="menu"></ul>
</span>
