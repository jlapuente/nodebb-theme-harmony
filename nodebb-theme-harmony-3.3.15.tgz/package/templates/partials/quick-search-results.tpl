{{{ if (multiplePages && !config.theme.topMobilebar) }}}
<div class="show-more-container">
	<div class="text-center d-block d-md-none">
		<a href="{url}" class="btn btn-sm btn-primary">{{tx("search:see-more-results", matchCount)}}</a>
	</div>
	<li role="separator" class="dropdown-divider d-block d-md-none"></li>
</div>
{{{ end }}}

<ul id="quick-search-results" class="quick-search-results list-unstyled mb-0 p-0 pe-1 overflow-auto overscroll-behavior-contain ff-base ghost-scrollbar" style="max-width: {dropdown.maxWidth}; max-height: {dropdown.maxHeight};">
	<li role="separator" class="dropdown-divider d-none d-md-block"></li>
	{{{ each posts }}}
	<li data-tid="{posts.topic.tid}" data-pid="{posts.pid}" class="d-flex flex-column gap-1">
		<a href="{config.relative_path}/post/{encodeURIComponent(posts.pid)}"
			class="btn btn-ghost btn-sm ff-secondary rounded-1 text-start text-reset d-block text-truncate px-2 py-1">
			<span class="quick-search-title fw-semibold text-sm">{posts.topic.title}</span>
			<br/>
			<p class="snippet text-xs text-break text-wrap mb-0">
			{posts.snippet}
			</p>
		</a>
		<div class="d-flex gap-2 post-info px-2 text-xs">
			<div class="category-item d-inline-block ff-secondary">
				{{buildCategoryLabel(posts.category, "span")}}
			</div>
			<span class="timeago text-muted" title="{posts.timestampISO}"></span>
		</div>
	</li>
	{{{ if !@last }}}
	<li role="separator" class="dropdown-divider"></li>
	{{{ end }}}
	{{{ end }}}

</ul>

{{{ if multiplePages }}}
<div class="text-center mt-2 d-none d-md-block">
	<a href="{url}" class="btn btn-sm btn-primary">{{tx("search:see-more-results", matchCount)}}</a>
</div>
{{{ end }}}
{{{ if (multiplePages && config.theme.topMobilebar) }}}
<div class="text-center mt-2 d-block d-md-none">
	<a href="{url}" class="btn btn-sm btn-primary">{{tx("search:see-more-results", matchCount)}}</a>
</div>
{{{ end }}}

{{{if !posts.length}}}
<div class="text-center no-results py-2 py-md-0">{{tx("search:no-matches")}}</div>
<li role="separator" class="dropdown-divider d-block d-md-none"></li>
{{{end}}}