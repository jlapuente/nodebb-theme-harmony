<li component="post" class="posts-list-item  {{{ if ./deleted }}} deleted{{{ else }}}{{{ if ./topic.deleted }}} deleted{{{ end }}}{{{ end }}}{{{ if ./topic.scheduled }}} scheduled{{{ end }}}" data-pid="{./pid}" data-uid="{./uid}">
	<hr/>
	<a class="topic-title fw-semibold fs-5 mb-1 text-reset text-break d-block" href="{config.relative_path}/post/{encodeURIComponent(./pid)}">
	{./topic.title}
	</a>

	<div class="post-body d-flex flex-column gap-3 mb-2">
		<div class="d-flex flex-wrap gap-2 post-info text-sm align-items-center">
			<div class="post-author d-flex align-items-center gap-1">
				<a class="lh-1 text-decoration-none" href="{config.relative_path}/user/{./user.userslug}">{{buildAvatar(./user, "16px", true, "not-responsive")}}</a>
				<a class="lh-1 fw-semibold" href="{config.relative_path}/user/{./user.userslug}">{{txDisplayname(./user)}}</a>
			</div>
			<span class="timeago text-muted lh-1" title="{./timestampISO}"></span>
			<div class="d-flex flex-wrap gap-1">
				{{buildCategoryLabel(./category, "a", "border")}}
				<span data-tid="{./topic.tid}" component="topic/tags" class="lh-1 tag-list d-flex flex-wrap gap-1 {{{ if !./topic.tags.length }}}hidden{{{ end }}}">
					{{{ each ./topic.tags }}}
					<a href="{config.relative_path}/tags/{./valueEncoded}"><span class="badge border border-gray-300 fw-normal tag tag-class-{./class}" data-tag="{./value}">{./value}</span></a>
					{{{ end }}}
				</span>
			</div>
		</div>

		<div component="post/content" class="content text-sm text-break">
			{{{ if ./contentWarning }}}
			<details class="content-warning">
			<summary>{./contentWarning}</summary>
			{{{ if ./txContent }}}{{tx(./content)}}{{{ else }}}{{./content}}{{{ end }}}
			</details>
			{{{ else }}}
			{{{ if ./txContent }}}{{tx(./content)}}{{{ else }}}{{./content}}{{{ end }}}
			{{{ end }}}
		</div>
	</div>
</li>